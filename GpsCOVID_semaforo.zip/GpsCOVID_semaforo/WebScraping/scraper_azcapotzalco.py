from urllib.request import urlopen
html = urlopen("https://www.camwhores.tv/videos/7050866/caylin-in-red/")
print(html.read())