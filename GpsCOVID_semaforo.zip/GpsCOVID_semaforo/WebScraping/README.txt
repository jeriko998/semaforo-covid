Codigo respecto a la programacion del web scraping del sitio web de la secretaria de salud
para la obtencion de los datos COVID que usará la aplicación.