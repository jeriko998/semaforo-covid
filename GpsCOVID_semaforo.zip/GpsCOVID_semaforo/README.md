Tesis GPS Semaforo COVID
Con sede y servicio para México, CDMX

Esta es una APP para presentar tesis, la cual se encargará de dar a conocer el nivel de alerta dentro de la CDMX 
